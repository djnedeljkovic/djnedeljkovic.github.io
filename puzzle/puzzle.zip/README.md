Puzzle generator
==================

Puzzle generator is a web application used to generate random puzzles from uploaded images.
